import requests
import endpoints
import data


def test_login_user():
    login_body = {
        "username": data.register_body["username"],
        "password": data.register_body["password"]
    }

    for attempt in range(10):
        try:
            login_response = requests.post(endpoints.login_endpoint, json=login_body)
            token = login_response.json().get('token')

            if token:
                print("Login successful.")
                data.headers['Authorization'] = f'Bearer {token}'
                break
            else:
                print("Login failed. Status code:", login_response.status_code)
                print("Response:", login_response.text)

        except requests.RequestException as e:
            print(e)
            print(f"Attempt {attempt + 1}: Login failed. Retrying...")

    return data.headers



