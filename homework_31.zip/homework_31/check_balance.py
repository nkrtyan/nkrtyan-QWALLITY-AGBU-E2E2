import requests
import endpoints
import data


def test_check_balance():
    for attempt in range(10):
        try:
            check_balance_response = requests.get(endpoints.get_balance_endpoint, headers=data.headers)

            if check_balance_response.status_code == 200:
                response_data = check_balance_response.json()
                actual_balance = response_data.get("balance")
                print("Balance retrieved successfully!")
                print("Current balance - ", actual_balance)

                assert actual_balance == data.balance_amount, (
                    f"Expected balance {data.balance_amount}, but got {actual_balance}"
                )
                print("Balance check passed!")
            else:
                print("Failed to get balance. Status code:", check_balance_response.status_code)
                print("Response:", check_balance_response.text)
            break

        except requests.RequestException as e:
            print(e)
            print(f"Attempt {attempt + 1}: Check balance failed. Retrying...")


test_check_balance()