import data
import endpoints
import requests


def test_register_user():
    register_data = data.register_body
    username = data.register_body["username"]
    password = data.register_body["password"]

    for attempt in range(10):
        try:
            register_user_response = requests.post(endpoints.register_endpoint, json=register_data)

            if register_user_response.status_code == 201:
                print("User registered successfully!")
                print(register_user_response.json())
                print("Username - ", username)
                print("Password - ", password)
            else:
                print("Failed to register user. Status code:", register_user_response.status_code)
                print("Response:", register_user_response.text)
            break

        except requests.RequestException as e:
            print(e)
            print(f"Attempt {attempt + 1}: Register failed. Retrying...")

    return username, password